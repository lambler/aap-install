# AAP 2.6 Single-Node Containerized Install Kit (vSphere VM, Podman) — NOT OpenShift

## This project was intedned to be flexible enough to be able to deploy from both CLI and AAP. It was broken up into multiple playbooks to reach certain stages.
## The intention of multiple stages is to provide a easy digestible workflow for troubleshooting purposes. 
## This forces the customer to create a workflow template in AAP so that in the event something fails; they would not have to rerun the entire code, but a section of the code. 


## Customer edits
- `inventories/customer1/hosts.ini` (set the single node IP + SSH user)
- `inventories/customer1/group_vars/all.yml` (FQDNs, bundle filename, etc.)
- Encrypt `aap_deploy/vault.yml` after it is created (recommended) and set passwords there.

## Run (from your deployer host)
```bash
ansible-galaxy collection install -r requirements.yml

# 1) Prep the target node (packages, sysctls, stop McAfee/InvMG, etc.)
ansible-playbook playbooks/01_prep_hosts.yml

# 2) Extract the bundle locally + create inventory-growth + stub vault.yml
ansible-playbook playbooks/02_prepare_bundle_local.yml

# 3) Run the containerized installer playbook from inside the extracted bundle
ansible-playbook playbooks/03_install_aap.yml

# 4) Health check
ansible-playbook playbooks/04_healthcheck.yml

# 5) Re-enable security services
ansible-playbook -i inventories/customer1/hosts.ini playbooks/05_post_install_security.yml
```

## Notes
- Place the official AAP 2.6 containerized setup tarball in `files/` and update `aap_bundle_local`.
- This kit intentionally does not use `infra.aap_utilities` for extraction to avoid variable drift like `aap_setup_down_installer_file`.
